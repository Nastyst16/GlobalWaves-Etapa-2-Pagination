package main.commands.player.host;

import com.fasterxml.jackson.annotation.JsonIgnore;
import main.Command;
import main.CommandVisitor;
import main.SearchBar;
import main.users.User;
import main.commands.types.Podcast;
import main.users.Artist;
import main.users.Host;

import java.util.ArrayList;

public final class RemovePodcast implements Command {
    private final String command;
    private final String user;
    private final int timestamp;
    @JsonIgnore
    private final String name;
    private String message;

    /**
     * execute method for visitor pattern
     * @param currUser the current user
     * @param artist the artist
     * @param host the host
     * @param users the users
     * @param podcasts the podcasts
     */
    public void execute(final User currUser, final Artist artist, final Host host,
                        final ArrayList<User> users, final ArrayList<Podcast> podcasts) {
        this.setRemovePodcast(currUser, artist, host, users, podcasts);
    }

    /**
     * method that removes a podcast
     * @param currUser the current user
     * @param artist the artist
     * @param host the host
     * @param users the users
     * @param podcasts the podcasts
     */
    public void setRemovePodcast(final User currUser, final Artist artist, final Host host,
                                 final ArrayList<User> users, final ArrayList<Podcast> podcasts) {

        if (currUser != null || artist != null) {
            this.setMessage(this.user + " is not an host.");
            return;
        } else if (host == null) {
            this.setMessage("The username " + this.user + " doesn't exist.");
            return;
        }

//        verifying if the podcast exists
        boolean exists = false;

        for (Podcast podcast : host.getHostPodcasts()) {
            if (podcast.getName().equals(this.name)) {
                exists = true;
                break;
            }
        }

        if (!exists) {
            this.setMessage(this.user + " doesn't have a podcast with the given name.");
            return;
        }

//        verifying if a users currently listens to the podcast
        for (User currentUser : users) {
            if (currentUser.getCurrentType() != null) {
                for (Podcast podcast : host.getHostPodcasts()) {
                    this.setMessage(this.user + " can't delete this podcast.");
                    return;
                }
            }
        }

//        deleting everything related to the podcast
        for (Podcast p : host.getHostPodcasts()) {

            for (User u : users) {

                u.setEveryPodcast(podcasts);
//                deleting also every user listened podcasts
                for (Podcast podcastToRemove : u.getPodcastsPlayed()) {
                    if (podcastToRemove.getName().equals(p.getName())) {

//                        removing the podcast from the user's listened podcasts
                        for (Podcast podcast : u.getPodcastsPlayed()) {
                            if (podcast.getName().equals(podcastToRemove.getName())) {
                                u.getPodcastsPlayed().remove(podcast);
                                break;
                            }
                        }

                        break;
                    }
                }
            }
        }

//        removing the podcast
        for (Podcast podcast : host.getHostPodcasts()) {
            if (podcast.getName().equals(this.name)) {
                host.getHostPodcasts().remove(podcast);
                podcasts.remove(podcast);
                break;
            }
        }


        this.setMessage(this.user + " deleted the podcast successfully.");
    }

    /**
     * constructor for the RemovePodcast class
     * @param input the input
     */
    public RemovePodcast(final SearchBar input) {
        this.command = input.getCommand();
        this.user = input.getUsername();
        this.timestamp = input.getTimestamp();
        this.name = input.getName();
    }

    /**
     * accept method for visitor pattern
     * @param visitor the visitor
     */
    public void accept(final CommandVisitor visitor) {
        visitor.visit(this);
    }

    /**
     * getter for the command
     * @return the command
     */
    public String getCommand() {
        return command;
    }

    /**
     * getter for the user
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * getter for the timestamp
     * @return the timestamp
     */
    public int getTimestamp() {
        return timestamp;
    }

    /**
     * getter for the name
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * getter for the message
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * setter for the message
     * @param message the message
     */
    public void setMessage(final String message) {
        this.message = message;
    }
}
