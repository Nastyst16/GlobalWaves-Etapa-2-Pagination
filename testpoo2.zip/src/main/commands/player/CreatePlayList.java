package main.commands.player;

import com.fasterxml.jackson.annotation.JsonIgnore;
import main.Command;
import main.CommandVisitor;
import main.commands.types.Playlist;
import main.SearchBar;
import main.users.User;

import java.util.ArrayList;

public final class CreatePlayList implements Command {
    private final String command;
    private final String user;
    private final int timestamp;
    private String playlistName;
    private String message;
    private  Playlist playlist;

    /**
     * executes the command CreatePlayList
     * @param input the input given by the user
     * @param currUser the user that issued the command
     * @param everyPlaylist the list of all playlists
     */
    public void execute(final SearchBar input, final User currUser,
                        final ArrayList<Playlist> everyPlaylist) {

//        if the currUser is offline
        if (!currUser.getOnline()) {
            this.setMessage(this.user + " is offline.");
            return;
        }

//                verify if a playlist with the same name exists;
        String msg = "Playlist created successfully.";
        for (Playlist p : everyPlaylist) {
            if (p.getName().equals(input.getPlaylistName())) {
                msg = "A playlist with the same name already exists.";
            }
        }

        this.setMessage(msg);

        if (!msg.equals("A playlist with the same name already exists.")) {
            currUser.addPlaylistToList(this.getPlaylist());
            everyPlaylist.add(this.getPlaylist());
        }

    }

    /**
     * accepts a visitor for the command
     * @param visitor the visitor
     */
    @Override
    public void accept(final CommandVisitor visitor) {
        visitor.visit(this);
    }


    /**
     * constructor for the command CreatePlayList
     * @param input the input given
     */
    public CreatePlayList(final SearchBar input) {

        this.command = input.getCommand();
        this.user = input.getUsername();
        this.timestamp = input.getTimestamp();
        this.message = null;

        this.playlist = new Playlist(input.getPlaylistName(), user);
    }

    /**
     * @return the command
     */
    public String getCommand() {
        return command;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @return the timestamp
     */
    public int getTimestamp() {
        return timestamp;
    }

    /**
     * @return the playlistName
     */
    public String getPlaylistName() {
        return playlistName;
    }

    /**
     * @param playlistName the playlistName to set
     */
    @JsonIgnore
    public void setPlaylistName(final String playlistName) {
        this.playlistName = playlistName;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * sets the message
     * @param message the message to set
     */
    public void setMessage(final String message) {
        this.message = message;
    }

    /**
     * @return playlist
     */
    public Playlist getPlaylist() {
        return playlist;
    }

    /**
     * @param playlist the playlist to set
     */
    @JsonIgnore
    public void setPlaylist(final Playlist playlist) {
        this.playlist = playlist;
    }


}
